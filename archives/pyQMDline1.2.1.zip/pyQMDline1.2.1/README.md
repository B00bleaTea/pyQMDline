## pyQMDline quickfix 1.2.1
#### sorry for the bugs, it's a lot for me to work with, but
#### don't worry, it's work in a fun way:D
***

### new features :
```text
NONE*
```

***

### fixes :
```text
> fixed the " if True else " statement in __main__.py - that was a mistake ! 
> fixed the way the ./commands/__init__.py file was indented
> removed the "python" key from PATH - that was a useless key
```

***

### general upgrades, updates and optimizations :
```text
> removed all piracy ( youtube downloader command )
> replaced timeout with sleep in windows alias setup file
> optimised imports
> cleaned the command files up,
    * added comments
    * removed unnecessary lines on code
    * added some checks to insure that the imports won't break
```

***

### notes
```text
> trying to find a way to autorun scripts better, suggest them in the issues
  tab with the tag of "suggestion"
> i might build and host a website on netlify:D
> DON'T be scared to be harsh, i want to hear the truth about
  my code so i could improve it, don't be scared to pull an issue.
```

***
***
## ~ sidenote ~
### please report any issues with pyQMDline [here](https://github.com/B00bleaTea/pyQMDline/issues/)
### thank you in advance :)
#### - B00bleaTeA
##### ! sorry for any inconsistencies or inaccuracies !
***
***
###### (c) Apache software license 2.0