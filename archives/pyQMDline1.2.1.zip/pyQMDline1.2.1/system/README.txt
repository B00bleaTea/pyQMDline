for this to work you might want and need to have these pip modules,

os
shutil
ast
colorama
sys
json
requests
subprocess
platform
webbrowser
psutil
time
tabulate

THESE MODULES MIGHT NOT BE INSTALLED BY DEFAULT:
colorama
webbrowser
psutil
tabulate
