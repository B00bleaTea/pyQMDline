import sys
import os
import json
import shutil
import requests
import subprocess
import platform
import webbrowser

from imports import Out, coloured
from colorama import Fore, Style
from ast import literal_eval
