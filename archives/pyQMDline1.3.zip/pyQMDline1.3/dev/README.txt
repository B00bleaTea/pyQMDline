this folder meant to be for tests and testing out concepts,
nothing here is final, this folder is unnecessary for this version of
pyQMDLine, you can delete it