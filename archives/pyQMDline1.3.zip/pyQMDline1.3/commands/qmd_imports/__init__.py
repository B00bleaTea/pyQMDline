import sys
import os
import json
import shutil
import requests
import subprocess
import platform
import webbrowser
import psutil
import time
import datetime
import GPUtil
import easygui

from pprint import pformat
from tabulate import tabulate
from imports import Out, coloured
from colorama import Fore, Style
