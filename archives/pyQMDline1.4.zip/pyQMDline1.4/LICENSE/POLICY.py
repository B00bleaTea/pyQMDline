# the policy of pyQMDline, if you modifying policy and/or the main code
# this product is yours / I'm irresponsible for your own actions,
# any further actions you take is your own fault.
# take care:)
POLICY = """

policy:
- do you agree that i'm not responsible for ANY data loss you might
experience while using any (for example: trash/rm) commands?

- do you agree that any modifications you or anyone make to this software
aka. running a rm while loop to remove your C: or / and it being harmful
doesn't make me the person who destroyed your computer and you have the FULL responsibility for it

- any 3rd party software you add will NOT make me guilty for destroying your computer
if it is malicious, be careful of what you download.

- you agree to https://ip.me/ 's policy for the ip command to get your IP
NONE of that information is going to me or the domain maintainer

tl;dr?
I'm not responsible for any actions you make, AKA. any commands you run,
any modifications or any other software you download. changing anything in the policy
and/or the has_agreed_to_policy.bool file makes me completely irresponsible
for any further actions you take. and you agree to all URLs used to get data policy.
		or for short:
		anything you do is your own fault and you agree to APIs used policy.

Do You Agree To My Policy?"""
