os.mkdir('./system/system-folders/trash') if not os.path.exists('./system/system-folders/trash') else shutil.rmtree(
	'./system/system-folders/trash') or os.mkdir('./system/system-folders/trash')
